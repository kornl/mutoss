#' A package to check Roxygen's sanity
#' @name helloRoxygen-package
#' @docType package
NA
