#' @include runit/collate/pants.R
#' @include runit/collate/shirt.R
roxygen()
