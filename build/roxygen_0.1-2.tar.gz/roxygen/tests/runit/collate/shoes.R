#' @include runit/collate/socks.R
#' @include runit/collate/undershorts.R
#' @include runit/collate/pants.R
roxygen()
