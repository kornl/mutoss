package af.statguitoolkit.io.datasets;

public class RFileFormatException extends Exception {
    public RFileFormatException(String message, Throwable cause) {
        super(message, cause);
    }
}
