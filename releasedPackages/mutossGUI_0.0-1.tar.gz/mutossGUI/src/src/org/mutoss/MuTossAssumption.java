package org.mutoss;

import java.util.List;

public class MuTossAssumption {
	public String assumption;
	public List<String> reasons;
}
