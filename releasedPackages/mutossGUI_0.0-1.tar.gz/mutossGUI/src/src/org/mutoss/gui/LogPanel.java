package org.mutoss.gui;

import javax.swing.JPanel;

public class LogPanel extends JPanel {
	
}
