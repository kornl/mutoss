package org.mutoss.gui.widgets;

import org.af.commons.widgets.lists.SplitList;

public class LevelOrderSL extends SplitList<String> {
}
